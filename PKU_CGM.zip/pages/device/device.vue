<template>
	<view>
		<button @click="startBluetoothDeviceDiscovery">Start Bluetooth Devices Discovery</button>
		<button @click="stopBluetoothDevicesDiscovery">Stop Bluetooth Devices Discovery</button>
		<uni-list>
			<uni-list-item
				v-for="(item, index) in devicesList"
				:title="item.deviceId"
				:note="item.name + item.RSSI"
				:show-arrow="true"
				@click="goBTS(item.deviceId)"
				:clickable="true"
			></uni-list-item>
		</uni-list>
	</view>
</template>

<script>
export default {
	data() {
		return {
			//是否已经打开蓝牙，默认为false，当蓝牙适配器初始化成功后为true
			isOpenBle: false,
			isOpenDiscovery: false,
			//主服务的UUID
			primaryUUID: 'FFF0',
			//设备列表
			devicesList: {},

			//设备Id
			deviceId: '',
			//服务Id
			serviceId: ''
		};
	},

	onLoad(e) {
		const { isOpenBle } = e;
		this.isOpenBle = isOpenBle;
	},

	onHide() {
		if (this.isOpenDiscovery) {
			stopBluetoothDevicesDiscovery();
		}
	},

	methods: {
		goBTS(deviceId) {
			uni.setStorage({
				key: 'deviceId',
				data: deviceId,
				success: function () {
					console.log('success');
				}
			});
			
			this.stopBluetoothDevicesDiscovery();
			
			uni.navigateTo({
				url: `../BTservice/BTservice`,
				success: (res) => {
					console.log('跳转成功' + deviceId);
				},
				fail: () => {
					console.log('跳转失败');
				},
				complete: () => {}
			});
		},

		startBluetoothDeviceDiscovery() {
			//在页面显示的时候判断是都已经初始化完成蓝牙适配器若成功，则开始查找设备
			uni.openBluetoothAdapter({
				success: (e) => {
					console.log('初始化蓝牙成功:' + e.errMsg);
				},
				fail: (e) => {
					console.log('初始化蓝牙失败，错误码：' + (e.errCode || e.errMsg));
					//this.btStatus=false
				}
			});

			
			let self = this;
			setTimeout(function () {
				console.log('开始搜寻智能设备');
				uni.showToast({
					title: '搜寻智能设备'
				});
				// CGM的主服务ID为FFF0
				this.isOpenDiscovery = true;
				uni.startBluetoothDevicesDiscovery({
					//services: ['fff0'],
					success: (res) => {
						console.log('查找新的低功耗蓝牙设备主服务为' + self.primaryUUID + '的CGM设备：' + JSON.stringify(res));
						self.onBluetoothDeviceFound();
					},
					fail: (res) => {
						console.log('查找设备失败!');
						uni.showToast({
							icon: 'none',
							title: '查找设备失败！',
							duration: 3000
						});
					}
				});
			}, 300);
		},
		/**
		 * 停止搜索蓝牙设备
		 */
		onBluetoothDeviceFound() {
			console.log('监听寻找新设备');
			//this.getBluetoothDevices();
			uni.onBluetoothDeviceFound((devices) => {
				//console.log('开始监听寻找到新设备的事件');
				this.getBluetoothDevices();
			});
		},

		getBluetoothDevices() {
			//console.log('获取蓝牙设备');
			uni.getBluetoothDevices({
				success: (res) => {
					this.devicesList = res.devices;
				},
				fail: (e) => {
					console.log('获取蓝牙设备错误，错误码：' + e.errCode);
				}
			});
		},

		/**
		 * 停止搜索蓝牙设备
		 */
		stopBluetoothDevicesDiscovery() {
			uni.stopBluetoothDevicesDiscovery({
				success: (e) => {
					console.log('停止搜索蓝牙设备:' + e.errMsg);
					this.isOpenDiscovery = false;
				},
				fail: (e) => {
					console.log('停止搜索蓝牙设备失败，错误码：' + e.errCode);
				}
			});
		},
		getBLEDeviceServices() {
			let deviceId = this.deviceId;
			let serviceList = [];
			let self = this;
			uni.getBLEDeviceServices({
				// 这里的 deviceId 需要已经通过 createBLEConnection 与对应设备建立链接
				deviceId,
				success: (res) => {
					console.log(JSON.stringify(res));
					serviceList = res.services;
					for (let i = 0; i < serviceList.length; i++) {
						let service = serviceList[i];
						console.log(JSON.stringify(service) + '----serviceID：' + service.uuid);
						//比对service是否是FFF0服务
						if (service.uuid.indexOf(self.primaryUUID) != -1) {
							self.serviceId = service.uuid;
							console.log('设备的serviceId： ' + self.serviceId);
							//开始获取指定服务的特征值
							self.getBLEDeviceCharacteristics();
							break;
						}
					}
				},
				fail: (res) => {
					console.log('device services:', res.services);
				}
			});
		}
	}
};
</script>

<style></style>
