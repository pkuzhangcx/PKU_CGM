<template>
	<view>
		<uni-list>
			<uni-list-item title="goto linechart" thumb="/static/iconfont/user2.png" link to ="/pages/linechart/linechart" ></uni-list-item>
			<uni-list-item title="goto piechart" thumb="/static/iconfont/user2.png" link to ="/pages/piechart/piechart" ></uni-list-item>
		</uni-list>
	</view>
</template>

<script>
	export default {
		
	}
</script>

<style scoped>

</style>