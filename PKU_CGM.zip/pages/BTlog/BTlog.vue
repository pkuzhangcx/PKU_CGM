<template>
	<view>
		<uni-section titleFontSize="20px" subTitleFontSize="18px" title="BaseSettings" type="line">
			<view class="example-body box">
				<button class="box" @click="closeBluetoothAdapter">Close BT</button>
				<button class="box" @click="golinechart">Go figure</button>
				<button class="box" @click="notifycurrent(notifyCid)">Notify</button>
				<button class="box" @click="exportLog">Export</button>
				<button class="box" @click="dialogToggle('warn')">Clean log</button>
			</view>
		</uni-section>
		<uni-section titleFontSize="20px" subTitleFontSize="18px" title="StrategySettings" type="line">
			<button class="bigb" @click="openStrategy">Open Strategy {{ status.StrategyStatus ? 'OFF' : 'ON' }}</button>
			<button class="bigb" @click="closeStrategy" :disabled="status.StrategyStatus">Close Strategy</button>
		</uni-section>
		<uni-section titleFontSize="20px" subTitleFontSize="18px" title="Before Meal" type="line">
			<view class="dialog-box">
				<text class="dialog-text">{{ sumInsulin }} V*min have been injected in 2 hours</text>
			</view>
			<button class="bigb" @click="openBeforeMealPopup">Open Before Meal (Auto) {{ status.MealStatus ? 'OFF' : 'ON' }}</button>
			<button class="bigb" @click="closeBeforeMeal" :disabled="status.MealStatus">Close Before Meal</button>
		</uni-section>
		<uni-section titleFontSize="20px" subTitleFontSize="18px" title="Settings" type="line">
<!-- 			<view class="dialog-box">
				<text class="dialog-text">可于此处修改配置，当前配置：</text>
			</view> -->
			<view class="dialog-box">
				<text class="dialog-text">slope a：{{baseSettingStorage.coefficient_a}} | intercept b:{{baseSettingStorage.coefficient_b}} | Maximum inject in 2 hours in the day：{{baseSettingStorage.maximum2hours}} | Maximum inject in 2 hours at night：{{baseSettingStorage.maximum2hours_night}} | Daytime start time：{{baseSettingStorage.daytime_begin}} | Daytime end time：{{baseSettingStorage.daytime_end}} | BG high limit：{{OCsettingStorage.upperLimit}} mM| BG Secondary high limit：{{OCsettingStorage.gluHighLevel}} mM | Secondary high V：{{OCsettingStorage.pumpHighLevelV}} mV</text>
			</view>
<!-- 			<view class="example-body box">
				<button class="box" @click="a_popup">slope a</button>
				<button class="box" @click="b_popup">intercept b</button>
				<button class="box" @click="max2hour_popup">Max in the day</button>
				<button class="box" @click="max2hour_night_popup">Maximun at night</button>
			</view> -->
<!-- 			<view class="example-body box">
				<button class="box" @click="dayBegin_popup">Daytime start time</button>
				<button class="box" @click="dayEnd_popup">Daytime end time</button>
				<button class="box" @click="upper_popup">BG limit</button>
				<button class="box" @click="gluHighLevel_popup">BG secondary high limit V</button>
				<button class="box" @click="pumpHighLevel_popup">Secondary high V</button>
			</view>	 -->		
		</uni-section>
<!-- 		<uni-section title="opt" type="line">
			<button type="default" @click="changeSV(100)">sv100</button>
			<button type="default" @click="changeSV(0)">sv0</button>
			<button type="default" @click="changePV(1000)">Pv1000</button>
			<button type="default" @click="changePV(0)">pv0</button>
		</uni-section> -->
		<view class="uni-padding-wrap uni-common-mt">
			<uni-segmented-control :current="tabmode" :values="tabItems" :style-type="styleType" :active-color="activeColor" @clickItem="onClickItem" />
		</view>
		<view class="content">
			<view v-if="tabmode === 0">
				<scroll-view scroll-y="true">
					<uni-list>
						<uni-list-item v-for="(item, index) in BLECurrentLog" :title="dateFormat(item.time) + ' Current:' + item.current"></uni-list-item>
					</uni-list>
				</scroll-view>
			</view>
			<view v-if="tabmode === 1">
				<scroll-view scroll-y="true">
					<uni-list>
						<uni-list-item v-for="(item, index) in BLEoperationLog" :title="dateFormat(item.time) + ' Operation:' + item.command"></uni-list-item>
					</uni-list>
				</scroll-view>
			</view>
			<view v-if="tabmode === 2">
				<scroll-view scroll-y="true">
					<uni-list>
						<uni-list-item v-for="(item, index) in BLElog60" :title="dateFormat(item.time) + ' Current:' + item.current"></uni-list-item>
					</uni-list>
				</scroll-view>
			</view>
		</view>

		<view>
			<uni-popup ref="beforeMeal" type="dialog">
				<uni-popup-dialog
					ref="inputClose"
					mode="input"
					title="餐前大剂量"
					value="20"
					@confirm="BeforeMealconfirm"
				></uni-popup-dialog>
			</uni-popup>
		</view>
		<view>
			<uni-popup ref="a" type="dialog">
				<uni-popup-dialog
					ref="inputClose"
					mode="input"
					title="斜率a"
					value="10"
					@confirm="a_confirm"
				></uni-popup-dialog>
			</uni-popup>
		</view>
		<view>
			<uni-popup ref="b" type="dialog">
				<uni-popup-dialog
					ref="inputClose"
					mode="input"
					title="截距b"
					value="400"
					@confirm="b_confirm"
				></uni-popup-dialog>
			</uni-popup>
		</view>
		<view>
			<uni-popup ref="max2hour" type="dialog">
				<uni-popup-dialog
					ref="inputClose"
					mode="input"
					title="白天2小时最大剂量"
					value="20"
					@confirm="max2hour_confirm"
				></uni-popup-dialog>
			</uni-popup>
		</view>
		<view>
			<uni-popup ref="max2hour_night" type="dialog">
				<uni-popup-dialog
					ref="inputClose"
					mode="input"
					title="夜间2小时最大剂量"
					value="15"
					@confirm="max2hour_night_confirm"
				></uni-popup-dialog>
			</uni-popup>
		</view>
		<view>
			<uni-popup ref="dayBegin" type="dialog">
				<uni-popup-dialog
					ref="inputClose"
					mode="input"
					title="白天开始时间"
					value="4"
					@confirm="dayBegin_confirm"
				></uni-popup-dialog>
			</uni-popup>
		</view>
		<view>
			<uni-popup ref="dayEnd" type="dialog">
				<uni-popup-dialog
					ref="inputClose"
					mode="input"
					title="白天结束时间"
					value="23"
					@confirm="dayEnd_confirm"
				></uni-popup-dialog>
			</uni-popup>
		</view>
		<view>
			<uni-popup ref="upper" type="dialog">
				<uni-popup-dialog
					ref="inputClose"
					mode="input"
					title="采用1V电压的血糖临界值"
					value="10"
					@confirm="upper_confirm"
				></uni-popup-dialog>
			</uni-popup>
		</view>
		<view>
			<uni-popup ref="gluHighLevel" type="dialog">
				<uni-popup-dialog
					ref="inputClose"
					mode="input"
					title="血糖次高临界值"
					value="7.8"
					@confirm="gluHighLevel_confirm"
				></uni-popup-dialog>
			</uni-popup>
		</view>
		<view>
			<uni-popup ref="pumpHighLevel" type="dialog">
				<uni-popup-dialog
					ref="inputClose"
					mode="input"
					title="达到次高临界值时泵电压(mV)"
					value="500"
					@confirm="pumpHighLevel_confirm"
				></uni-popup-dialog>
			</uni-popup>
		</view>

		<view>
			<!-- 提示窗示例 -->
			<uni-popup ref="alertDialog" type="dialog">
				<uni-popup-dialog :type="msgType" cancelText="关闭" confirmText="同意" title="通知" content="是否清空日志" @confirm="dialogConfirm"></uni-popup-dialog>
			</uni-popup>
		</view>
	</view>
</template>

<script>
// ArrayBuffer转16进度字符串示例
function ab2hex(buffer) {
	const hexArr = Array.prototype.map.call(new Uint8Array(buffer), function (bit) {
		return ('00' + bit.toString(16)).slice(-2);
	});
	return hexArr.join('');
}

function hexStringToByteArray(hexString) {
	if (!hexString.length) {
		return new Uint8Array();
	}
	const byteArray = new Uint8Array(hexString.length / 2);
	for (let i = 0; i < hexString.length; i += 2) {
		const byte = parseInt(hexString.substr(i, 2), 16);
		byteArray[i / 2] = byte;
	}
	return byteArray;
}

import * as my_file from './test.js';

// import Charsets from 'kotlin.text.Charsets';

export default {
	data() {
		return {
			//设备Id
			deviceId: '',
			//服务Id
			serviceId: '',
			//读写Id
			writeCId: '',
			notifyCid: '',
			Name: 'BLE_config',
			status: {
				StrategyStatus: true,
				MealStatus: true
			},

			BLElog: [],
			BLEoperationLog: [],
			BLECurrentLog: [],
			BLEPumpVLog: [],
			BLElog60: [],
			glulog: [],
			StrategyMode: 1,
			tabmode: 0,
			tabItems: ['Current Log', 'Operation Log', 'Recent Current'],
			styleType: 'button',
			activeColor: '#dd524d',
			OpenLooptimer: {
				Looptimer: '',
				CloseSVtimer: '',
				OpenPVtimer: '',
				ClosePVtimer: ''
			},
			MealLooptimer: {
				Looptimer: '',
				ClosePVtimer: ''
			},

			StrategyList: [
				{ value: 0, text: '硬件原生' },
				{ value: 1, text: '开环策略' },
				{ value: 2, text: '混合闭环' }
			],
			StrategyName: '',

			nontimer: '',
			msgType: 'success',
			type: 'center',

			ischange: false,
			write_Time: '',
			sumInsulin:0,

			baseSettingStorage: {
				coefficient_a: 10,
				coefficient_b: 400,
				maximum2hours: 21,
				maximum2hours_night: 15,
				daytime_begin: 4,
				daytime_end: 22,
				beforeMeal: 10
			},
			OCsettingStorage: {
				upperLimit: 10,
				lowerLimit: 3.9,
				gluHighLevel: 7.8,
				pumpHighLevelV: 500,
				pumpMidLevelV: 0,
				gluLowLevel: 5,
				pumpLowLevelV: 0
			}
		};
	},
	watch: {
		BLElog: {
			//深度监听，可监听到对象、数组的变化
			handler(val, oldVal) {
				//console.log('b.c: ' + val.c, oldVal.c);
				this.ischange = true;
				if (!this.write_Time) {
					this.write_Time = setInterval(this.changeData, 60000);
				}
			},
			deep: true //true 深度监听
		}
	},
	onShow() {
		setTimeout(() => {
			const deviceId = uni.getStorageSync('deviceId');
			const serviceId = uni.getStorageSync('serviceId');
			const notifyCid = uni.getStorageSync('notifyCid');
			const writeCId = uni.getStorageSync('writeCId');
			const StrategyMode = uni.getStorageSync('StrategyMode');
			this.deviceId = deviceId;
			this.serviceId = serviceId;
			this.notifyCid = notifyCid;
			this.StrategyMode = StrategyMode;
			this.writeCId = writeCId;
			console.log('加载蓝牙信息，策略为', StrategyMode);

			this.StrategyName = this.StrategyList[StrategyMode].text;
		}, 30);

		setTimeout(() => {
			const status = uni.getStorageSync('status');
			if (status) {
				this.status = JSON.parse(status);
				console.log('策略模式更改');
			}

			const OpenLooptimer = uni.getStorageSync('OpenLooptimer');
			if (OpenLooptimer) {
				this.OpenLooptimer = JSON.parse(OpenLooptimer);
				console.log('策略定时器参数记录');
			}

			const MealLooptimer = uni.getStorageSync('MealLooptimer');
			if (MealLooptimer) {
				this.MealLooptimer = JSON.parse(MealLooptimer);
				console.log('大剂量定时器参数记录');
			}

			const baseSetting = uni.getStorageSync('baseSetting');
			if (baseSetting) {
				this.baseSettingStorage = JSON.parse(baseSetting);
				console.log('基础配置完成加载', this.baseSettingStorage);
			}

			const OCsetting = uni.getStorageSync('OCsetting');
			if (OCsetting) {
				this.OCsettingStorage = JSON.parse(OCsetting);
				console.log('闭环配置完成加载', this.OCsettingStorage);
			}

			const BLECurrentLog = uni.getStorageSync('BLECurrentLog');
			if (BLECurrentLog) {
				this.BLECurrentLog = JSON.parse(BLECurrentLog);
				console.log('电流日志完成加载', this.BLECurrentLog);
			}

			const BLElog = uni.getStorageSync('BLElog');
			if (BLElog) {
				this.BLElog = JSON.parse(BLElog);
				console.log('详细电流完成加载');
			}

			const BLEPumpVLog = uni.getStorageSync('BLEPumpVLog');
			if (BLEPumpVLog) {
				this.BLEPumpVLog = JSON.parse(BLEPumpVLog);
				console.log('详细电流完成加载');
			}

			const BLEoperationLog = uni.getStorageSync('BLEoperationLog');
			if (BLEoperationLog) {
				this.BLEoperationLog = JSON.parse(BLEoperationLog);
				console.log('操作日志完成加载', this.BLEoperationLog);
			}
		}, 40);
	},

	mounted() {
		this.onBLEConnectionStateChange();
	},

	methods: {
		openBeforeMealPopup() {
			this.$refs.beforeMeal.open();
		},
		
		BeforeMealconfirm(val){
			
			this.baseSettingStorage.beforeMeal = val;
			this.openBeforeMeal();
		},
		//系数a
		a_popup(){
			this.$refs.a.open();
		},
		a_confirm(val){	
			this.baseSettingStorage.coefficient_a = val;
		},
		//系数b
		b_popup(){
			this.$refs.b.open();
		},
		b_confirm(val){	
			this.baseSettingStorage.coefficient_b = val;
		},
		//白天2小时最大量
		max2hour_popup(){
			this.$refs.max2hour.open();
		},
		max2hour_confirm(val){	
			this.baseSettingStorage.maximum2hours = val;
		},
		//夜间2小时最大量
		max2hour_night_popup(){
			this.$refs.max2hour_night.open();
		},
		max2hour_night_confirm(val){	
			this.baseSettingStorage.maximum2hours_night = val;
		},
		//白天开始时间
		dayBegin_popup(){
			this.$refs.dayBegin.open();
		},
		dayBegin_confirm(val){	
			this.baseSettingStorage.daytime_begin = val;
		},
		//白天结束时间
		dayEnd_popup(){
			this.$refs.dayEnd.open();
		},
		dayEnd_confirm(val){	
			this.baseSettingStorage.daytime_end = val;
		},
		//血糖上限
		upper_popup(){
			this.$refs.upper.open();
		},
		upper_confirm(val){	
			this.OCsettingStorage.upperLimit = val;
		},
		//血糖次高限
		gluHighLevel_popup(){
			this.$refs.gluHighLevel.open();
		},
		gluHighLevel_confirm(val){	
			this.OCsettingStorage.gluHighLevel = val;
		},
		//次高泵压
		pumpHighLevel_popup(){
			this.$refs.pumpHighLevel.open();
		},
		pumpHighLevel_confirm(val){	
			this.OCsettingStorage.pumpHighLevelV = val;
		},

		//修改传感电压
		changeSV(sensorV) {
			let changeSVcommand = '8001';
			let sensorVHEX = sensorV.toString(16);
			sensorVHEX = sensorVHEX.padStart(4, '0');
			console.log('SVHEX:' + sensorVHEX);
			changeSVcommand = changeSVcommand.concat(sensorVHEX);
			console.log(changeSVcommand);
			this.writeBLE(changeSVcommand);
			this.pushCommandInlog('changeSensorVoltage:' + sensorV + 'mV');
			console.log('修改传感电压完成');

			let BLEoperationLog = JSON.stringify(this.BLEoperationLog);

			uni.setStorage({
				key: 'BLEoperationLog',
				data: BLEoperationLog,
				success: function () {
					console.log('成功写入日志文件BLEoperationLog');
				},
				fail: function () {
					console.log('写入日志文件失败BLEoperationLog');
				}
			});
		},

		//修改泵电压
		changePV(pumpV) {
			let changePVcommand = '8002';
			let pumpVHEX = pumpV.toString(16);
			pumpVHEX = pumpVHEX.padStart(4, '0');
			console.log('pumpVHEX:' + pumpVHEX);
			changePVcommand = changePVcommand.concat(pumpVHEX);
			console.log(changePVcommand);
			this.writeBLE(changePVcommand);
			this.pushCommandInlog('changePumpVoltage:' + pumpV + 'mV');
			console.log('修改泵电压完成');

			let BLEoperationLog = JSON.stringify(this.BLEoperationLog);

			uni.setStorage({
				key: 'BLEoperationLog',
				data: BLEoperationLog,
				success: function () {
					console.log('成功写入日志文件BLEoperationLog');
				},
				fail: function () {
					console.log('写入日志文件失败BLEoperationLog');
				}
			});
		},

		//传感电流阈值
		changeCT(CurrentTh) {
			let changeCTcommand = '8003';
			let CurrentThHEX = CurrentTh.toString(16);
			CurrentThHEX = CurrentThHEX.padStart(4, '0');
			console.log('CurrentThHEX:' + CurrentThHEX);
			changeCTcommand = changeCTcommand.concat(CurrentThHEX);
			this.writeBLE(changeCTcommand);
			this.pushCommandInlog('changeCurrentThreshold:' + CurrentTh + 'mV');

			let BLEoperationLog = JSON.stringify(this.BLEoperationLog);

			uni.setStorage({
				key: 'BLEoperationLog',
				data: BLEoperationLog,
				success: function () {
					console.log('成功写入日志文件BLEoperationLog');
				},
				fail: function () {
					console.log('写入日志文件失败BLEoperationLog');
				}
			});
		},

		//写入蓝牙数据
		writeBLE(command) {
			let deviceId = this.deviceId;
			let serviceId = this.serviceId;
			let characteristicId = this.writeCId;

			// 向蓝牙设备发送一个0x00的16进制数据

			const hexString = command; // 对应于"Hello"
			const byteArray = hexStringToByteArray(hexString);
			console.log(byteArray); // 输出: Uint8Array [72, 101, 108, 108, 111]

			console.log(characteristicId);
			uni.writeBLECharacteristicValue({
				// 这里的 deviceId 需要在 getBluetoothDevices 或 onBluetoothDeviceFound 接口中获取
				deviceId,
				// 这里的 serviceId 需要在 getBLEDeviceServices 接口中获取
				serviceId,
				// 这里的 characteristicId 需要在 getBLEDeviceCharacteristics 接口中获取
				characteristicId,
				// 这里的value是ArrayBuffer类型
				value: byteArray,
				success(res) {
					console.log('writeBLECharacteristicValue success' + command, res.errMsg);
				},
				fail(res) {
					console.log('写入失败' + command, res.errMsg);
				}
			});
		},

		exportLog20() {
			let log20 = [];
			for (let i = 0; i < 20; i++) {
				log20 = log20.concat(this.BLElog);
				this.exportLog();
			}
		},

		//导出日志
		async exportLog() {
			console.log(4666);
			console.log(this.ischange);

			// this.BLElog.push({
			// 	tes:'测试',
			// 	name:'你好'
			// })

			// 导出文件
			let data = JSON.parse(await my_file.getJsonData('log')) || [];
			if (!this.ischange) {
				// data=data.concat(this.BLElog)
				data = this.BLElog;
			}
			if (!data) {
				uni.showModal({
					title: '提示',
					content: '无数据'
				});
				return;
			}

			uni.showLoading({
				title: '导出中'
			});

			// console.log(7888);
			// console.log(data);

			uni.request({
				url: `https://fc-mp-ae830c98-bb43-4f1e-adbc-cb79a5814bc9.next.bspapp.com/loglist700`, //请求地址',
				// url: this.request_url,
				method: 'POST',
				data: {
					type: '0',
					data
				},
				success: (res) => {
					uni.hideLoading();
					console.log(9999);
					console.log(res);
					if (res.data.code == 200) {
						uni.showModal({
							title: '提示',
							content: '导出成功\r请复制后在浏览器打开下载地址',
							confirmText: '复制下载地址',
							success: function (res) {
								if (res.confirm) {
									uni.showToast({
										title: '已复制',
										duration: 2000
									});

									uni.setClipboardData({
										data: 'https://zserve.love/dowload700/dowload700.html', // e是你要保存的内容
										success: function () {
											uni.showToast({
												title: '复制成功',
												icon: 'none'
											});
										}
									});
								}
							}
						});
					}
				}
			});
		},
		async changeData() {
			if (!this.ischange) {
				return;
			}

			let log = [];

			try {
				let histy = JSON.parse(await my_file.getJsonData('log')) || [];
				if (histy.length > 604800) {
					histy = histy.slice(0, 604800);
				}
				// log=histy.concat(this.BLElog)
				log = this.BLElog;
			} catch (e) {
				log = [];
			}

			// console.log(81111);
			// console.log(log);

			// log=""
			//写入文件
			my_file.changeData('log', 0, log).then((res) => {
				this.ischange = false;
			});
		},

		openloopCheckpumpV(current) {
			let pumpV = 0;
			//g = (c-b)/a
			let coefficient_a = 0;
			coefficient_a = this.baseSettingStorage.coefficient_a;
			let coefficient_b = 0;
			coefficient_b = this.baseSettingStorage.coefficient_b;
			let glucose = Math.round((current - coefficient_b) / coefficient_a);
			console.log('公式为', glucose, '=', current, '-', coefficient_b, ' ', coefficient_a);
			console.log('血糖浓度为:', glucose);
			if (this.checkInsulin(glucose) == 0) {
				pumpV = 0;
			} else if (glucose >= this.OCsettingStorage.upperLimit) {
				pumpV = 1000;
			} else if (glucose >= this.OCsettingStorage.gluHighLevel) {
				pumpV = this.OCsettingStorage.pumpHighLevelV;
			} else if (glucose >= this.OCsettingStorage.gluLowLevel) {
				pumpV = this.OCsettingStorage.pumpMidLevelV;
			} else if (glucose >= this.OCsettingStorage.lowerLimit) {
				pumpV = this.OCsettingStorage.pumpLowLevelV;
			} else if (glucose < this.OCsettingStorage.lowerLimit) {
				pumpV = 0;
			}

			let logdata = {
				time: '',
				glucose: ''
			};
			logdata.time = Date.now();
			logdata.glucose = glucose;

			const newLength = this.glulog.push(logdata);

			let glulog = JSON.stringify(this.glulog);

			uni.setStorage({
				key: 'glulog',
				data: glulog,
				success: function () {
					console.log('成功写入日志文件glulog');
				},
				fail: function () {
					console.log('写入日志文件失败glulog');
				}
			});

			this.getBLEchartData(current, pumpV);
			return pumpV;
		},

		//选择策略模式
		openStrategy() {
			let mode = this.StrategyMode;
			if (mode == 0) {
				this.noneStrategy();
			} else if (mode == 1) {
				this.openloopStrategy();
			} else if (mode == 2) {
				this.DNmodeStrategy();
			}
		},

		noneStrategy() {
			this.status.StrategyStatus = false;
			let status = JSON.stringify(this.status);
			uni.setStorageSync('status', status);
			this.changeSV(100);
			setTimeout(() => {
				this.changePV(1000);
			}, 400);

			setTimeout(() => {
				this.changeCT(360);
			}, 800);

			setTimeout(() => {
				this.writeBLE('0x80040000');
			}, 1200);

			setTimeout(() => {
				this.writeBLE('0x80050001');
			}, 1600);
			setTimeout(() => {
				this.writeBLE('0x80060032');
			}, 2000);
			setTimeout(() => {
				this.writeBLE('0x800700B4');
			}, 2400);
			setTimeout(() => {
				this.writeBLE('0x8008003C');
			}, 2800);

			let nontimer = setInterval(() => {
				this.getcurrent();
			}, 60000);

			this.nontimer = nontimer;
		},

		getBLEchartData(current, pumpV) {},

		DNmodeStrategy() {},

		//开环策略
		openloopStrategy() {
			let sensorV = 100;
			let pumpV = 1000;
			let current = 0;
			let BLElog = '';
			this.status.StrategyStatus = false;
			let status = JSON.stringify(this.status);
			uni.setStorageSync('status', status);

			uni.showToast({
				icon: 'none',
				title: '开始开环策略！',
				mask: false,
				duration: 3000
			});
			let timer = {
				Looptimer: '',
				CloseSVtimer: '',
				OpenPVtimer: '',
				ClosePVtimer: ''
			};

			console.log('开启传感电压');
			this.changeSV(sensorV);
			timer.CloseSVtimer = setTimeout(() => {
				console.log('关闭传感电压');
				current = this.getcurrent(); //获取50秒后的电流值
				this.changeSV(0);
			}, 50000); //50秒之后关闭
			timer.OpenPVtimer = setTimeout(() => {
				console.log('开启泵电压电压');
				pumpV = this.openloopCheckpumpV(current);
				console.log('测算得泵电压应为:', pumpV);
				this.changePV(pumpV);
			}, 60000); //60秒后判断并开启泵电压
			timer.ClosePVtimer = setTimeout(() => {
				console.log('关闭泵电压电压');
				this.changePV(0);
				this.pushBLEPumplog(pumpV, 180000);

				BLElog = JSON.stringify(this.BLElog);
				uni.setStorage({
					key: 'BLElog',
					data: BLElog,
					success: function () {
						console.log('成功保存日志文件BLElog');
					},
					fail: function () {
						console.log('保存日志文件失败BLElog');
					}
				});
			}, 240000); //再过180秒关闭泵电压

			timer.Looptimer = setInterval(() => {
				console.log('开启传感电压');
				this.changeSV(sensorV);
				timer.CloseSVtimer = setTimeout(() => {
					console.log('关闭传感电压');
					current = this.getcurrent(); //获取50秒后的电流值
					this.changeSV(0);
				}, 50000); //50秒之后关闭
				timer.OpenPVtimer = setTimeout(() => {
					console.log('开启泵电压电压');
					pumpV = this.openloopCheckpumpV(current);
					console.log('测算得泵电压应为:', pumpV);
					this.changePV(pumpV);
				}, 60000); //60秒后判断并开启泵电压
				timer.ClosePVtimer = setTimeout(() => {
					console.log('关闭泵电压电压');
					this.changePV(0);
					this.pushBLEPumplog(pumpV, 180000);

					BLElog = JSON.stringify(this.BLElog);
					uni.setStorage({
						key: 'BLElog',
						data: BLElog,
						success: function () {
							console.log('成功保存日志文件BLElog');
						},
						fail: function () {
							console.log('保存日志文件失败BLElog');
						}
					});
					this.onBLEConnectionStateChange();
				}, 240000); //再过180秒关闭泵电压
			}, 300000);
			this.OpenLooptimer = timer;

			let OpenLooptimer = JSON.stringify(this.OpenLooptimer);
			uni.setStorageSync('OpenLooptimer', OpenLooptimer);
		},

		checkInsulin(glucose) {
			let len = this.BLEPumpVLog.length;
			console.log('BLEPumpVLog长度为:', len);
			let maxSum = 0;
			let maxSum_day = 0;
			let maxSum_night = 0;
			let timeinterval = 0;
			let daybegin = 4;
			let dayend = 23;
			let nowhour = 0;
			let Nowdate = new Date(this.BLEPumpVLog[len - 1].datetime);
			maxSum_day = this.baseSettingStorage.maximum2hours * 60 * 1000 * 1000;
			maxSum_night = this.baseSettingStorage.maximum2hours_night * 60 * 1000 * 1000;
			daybegin = this.baseSettingStorage.daytime_begin;
			dayend = this.baseSettingStorage.daytime_end;

			console.log('两小时内最大摄入胰岛素量为(mV*ms)', maxSum);
			let sumInsulin = 0;
			if (len == 0) {
				return 1;
			} else if (len < 24) {
				nowhour = Nowdate.getHours();
				if (nowhour > daybegin && nowhour < dayend) {
					maxSum = maxSum_day;
					console.log("现在是白天，时间为", nowhour);
				} else {
					maxSum = maxSum_night;
					console.log("现在是晚上，时间为", nowhour);
				}

				for (let i = 0; i < len; i++) {
					timeinterval = this.BLEPumpVLog[len - 1].datetime - this.BLEPumpVLog[len - 1 - i].datetime;
					if (timeinterval < 7200000) {
						sumInsulin = sumInsulin + this.BLEPumpVLog[len - 1 - i].pumpV * this.BLEPumpVLog[len - 1 - i].duringtime;
						//...
						console.log("计算公式为：",this.BLEPumpVLog[len - 1 - i].pumpV,this.BLEPumpVLog[len - 1 - i].duringtime);
						console.log('累计摄入胰岛素量为(mV*ms)', sumInsulin, timeinterval);
					}
				}
				console.log('两小时内摄入胰岛素量为(mV*ms)', sumInsulin);
				this.sumInsulin = sumInsulin/1000/60/1000;
				if (sumInsulin >= maxSum) {
					return 0;
				} else {
					return 1;
				}
			} else {
				nowhour = this.BLEPumpVLog[len - 1].datetime.getHours();
				if (nowhour > daybegin && nowhour < dayend) {
					maxSum = maxSum_day;
					console.log("现在是白天，时间为", nowhour);
				} else {
					maxSum = maxSum_night;
					console.log("现在是晚上，时间为", nowhour);
				}

				for (let i = 0; i < 24; i++) {
					timeinterval = this.BLEPumpVLog[len - 1].datetime - this.BLEPumpVLog[len - 1 - i].datetime;
					if (timeinterval < 7200000) {
						sumInsulin = sumInsulin + this.BLEPumpVLog[len - 1 - i].pumpV * this.BLEPumpVLog[len - 1 - i].duringtime;
						//...
						console.log('累计摄入胰岛素量为(mV*ms)', sumInsulin, timeinterval);
					}
				}
				console.log('两小时内摄入胰岛素量为(mV*ms)', sumInsulin);
				if (sumInsulin >= maxSum) {
					return 0;
				} else {
					return 1;
				}
			}
		},

		closeStrategy() {
			let timer = this.OpenLooptimer;
			this.clearIntervalTimer(timer.Looptimer);
			this.clearTimeoutTimer(timer.ClosePVtimer);
			this.clearTimeoutTimer(timer.CloseSVtimer);
			this.clearTimeoutTimer(timer.OpenPVtimer);
			this.changePV(0);
			setTimeout(() => {
				this.changeSV(0);
			}, 1000);

			console.log('策略计时器成功关闭');
			this.status.StrategyStatus = true;
			let status = JSON.stringify(this.status);
			uni.setStorageSync('status', status);
		},

		hybridClosedloopStrategy() {},

		openBeforeMeal() {
			//先关闭策略
			let sensorV = 100;
			let currentdata = 0;
			this.closeStrategy();
			this.status.MealStatus = false;
			let status = JSON.stringify(this.status);
			uni.setStorageSync('status', status);
			let maxtime = 0;
			maxtime = this.baseSettingStorage.beforeMeal * 60 * 1000 + 10;
			console.log('开启餐前大剂量,剂量为(ms)', maxtime);
			let mealtimer = setTimeout(() => {
				setTimeout(() => {
					this.closeBeforeMeal();
				}, 1000);
				setTimeout(() => {
					this.openStrategy();
				}, 2000);
				//再开启策略
			}, maxtime);
			let MealLooptimer = {
				Looptimer: '',
				ClosePVtimer: '',
				CloseSVtimer: '',
				OpenPVtimer: ''
			};

			let current = 0;

			console.log('开启传感电压');
			this.changeSV(sensorV);
			MealLooptimer.CloseSVtimer = setTimeout(() => {
				console.log('关闭传感电压');
				current = this.getcurrent(); //获取50秒后的电流值
				this.changeSV(0);
			}, 50000); //50秒之后关闭

			MealLooptimer.OpenPVtimer = setTimeout(() => {
				console.log('开启泵电压');
				this.changePV(1000);
			}, 60000); //60秒后判断并开启泵电压

			MealLooptimer.ClosePVtimer = setTimeout(() => {
				console.log('关闭泵电压');
				this.changePV(0);
				this.pushBLEPumplog(1000, 180000);
				currentdata = this.getcurrent();
			}, 240000); //再过120秒关闭泵电压

			MealLooptimer.Looptimer = setInterval(() => {
				console.log('开启传感电压');
				this.changeSV(sensorV);
				MealLooptimer.CloseSVtimer = setTimeout(() => {
					console.log('关闭传感电压');
					current = this.getcurrent(); //获取50秒后的电流值
					this.changeSV(0);
				}, 50000); //50秒之后关闭

				MealLooptimer.OpenPVtimer = setTimeout(() => {
					console.log('开启泵电压');
					this.changePV(1000);
				}, 60000); //60秒后判断并开启泵电压

				MealLooptimer.ClosePVtimer = setTimeout(() => {
					console.log('关闭泵电压');
					this.changePV(0);
					this.pushBLEPumplog(1000, 180000);
					currentdata = this.getcurrent();
				}, 240000); //再过120秒关闭泵电压
			}, 300000);
			this.MealLooptimer = MealLooptimer;

			let MealLooptimerJS = JSON.stringify(this.MealLooptimer);
			uni.setStorageSync('MealLooptimer', MealLooptimerJS);
		},

		closeBeforeMeal() {
			let timer = this.MealLooptimer;
			this.clearIntervalTimer(timer.Looptimer);
			this.clearTimeoutTimer(timer.ClosePVtimer);
			this.changePV(0);
			console.log('餐前大剂量已停止');
			this.status.MealStatus = true;
			let status = JSON.stringify(this.status);
			uni.setStorageSync('status', status);
		},

		pushBLEPumplog(pumpV, time) {
			let logdata = {
				datetime: '',
				duringtime: '',
				pumpV: ''
			};
			logdata.datetime = Date.now();
			logdata.duringtime = time;
			logdata.pumpV = pumpV;
			const newLength = this.BLEPumpVLog.push(logdata);
			console.log('泵电压数据已存储');

			let BLEPumpVLog = JSON.stringify(this.BLEPumpVLog);

			uni.setStorage({
				key: 'BLEPumpVLog',
				data: BLEPumpVLog,
				success: function () {
					console.log('成功保存日志文件BLEPumpVLog');
				},
				fail: function () {
					console.log('保存日志文件失败BLEPumpVLog');
				}
			});
		},

		//获取并保存电流日志
		getcurrent() {
			let len = this.BLElog60.length;
			console.log('长度为', len);
			let SumBLEcurrent = 0;
			for (let i = 0; i < 5; i++) {
				SumBLEcurrent = SumBLEcurrent + this.BLElog60[len - 1 - i].current;
				console.log('电流为', this.BLElog60[len - 1 - i].current);
				//...
			}
			// console.log("前五个点电流分别为:",this.BLElog[len - 1].current,this.BLElog[len - 2].current,this.BLElog[len - 3].current,this.BLElog[len - 4].current,this.BLElog[len - 5].current,"合计",SumBLEcurrent);
			let BLEcurrent = Math.round(SumBLEcurrent / 5);
			let currentdata = {
				time: '',
				current: ''
			};
			console.log('测试电流:' + BLEcurrent);

			currentdata.time = Date.now();
			currentdata.current = BLEcurrent;
			const newLength = this.BLECurrentLog.push(currentdata);

			if (currentdata.time - this.BLElog60[len - 1].time > 200000) {
				console.log('监听功能已停止运行');
				this.notifycurrent(this.notifyCid);
				this.pushCommandInlog('Notifycurrent cannot work, try reconnect Bluetooth');
			}

			let BLECurrentLog = JSON.stringify(this.BLECurrentLog);

			uni.setStorage({
				key: 'BLECurrentLog',
				data: BLECurrentLog,
				success: function () {
					console.log('成功保存日志文件BLECurrentLog');
				},
				fail: function () {
					console.log('保存日志文件失败BLECurrentLog');
				}
			});
			return BLEcurrent;
		},

		//清楚定时器
		clearIntervalTimer(timer) {
			// clearTime
			if (timer) {
				clearInterval(timer);
				timer = null;
				console.log('关闭定时器');
			}
		},

		clearTimeoutTimer(timer) {
			// clearTime
			if (timer) {
				clearTimeout(timer);
				timer = null;
				console.log('关闭定时器');
			}
		},

		//修改选项卡
		onClickItem(e) {
			if (this.tabmode !== e.currentIndex) {
				this.tabmode = e.currentIndex;
			}
		},

		dialogToggle(type) {
			this.msgType = type;
			this.$refs.alertDialog.open();
		},

		dialogConfirm() {
			console.log('点击确认');
			this.clearLog();
		},

		pushCommandInlog(command) {
			let logdata = {
				time: '',
				command: ''
			};
			logdata.time = Date.now();
			logdata.command = command;
			const newLength = this.BLEoperationLog.push(logdata);
		},

		//跳转图表
		golinechart() {
			uni.navigateTo({
				url: `../linechart/linechart`,
				success: (res) => {
					console.log('跳转成功');
				},
				fail: () => {
					console.log('跳转失败');
				},
				complete: () => {}
			});
		},

		//监听蓝牙电流值
		notifycurrent(characteristicId) {
			let deviceId = this.deviceId;
			let serviceId = this.serviceId;
			uni.notifyBLECharacteristicValueChange({
				deviceId,
				serviceId,
				characteristicId,
				success: (res) => {
					console.log('监听成功' + res);
					this.pushCommandInlog('notify success!');
					this.listencurrent();
				},
				fail: (res) => {
					console.log('监听失败' + res);
					this.pushCommandInlog('notify fail!');
					setTimeout(() => {
						this.recreateBLEConnection();
					}, 1000);
				}
			});
		},

		//电流保存到BLElog数组中
		listencurrent() {
			uni.onBLECharacteristicValueChange((res) => {
				// 结果

				// 结果里有个value值，该值为 ArrayBuffer 类型，所以在控制台无法用肉眼观察到，必须将该值转换为16进制
				let resHex = ab2hex(res.value);
				//console.log(resHex);
				let current1 = resHex.slice(2, 4);
				let current2 = resHex.slice(4, 6);
				// 最后将16进制转换为ascii码，就能看到对应的结果
				let current = parseInt(current1, 16) * 256 + parseInt(current2, 16);
				let logdata = {
					time: '',
					current: ''
				};
				logdata.time = Date.now();
				logdata.current = current;

				const newLength = this.BLElog.push(logdata);
				let BLEloglen = this.BLElog.length;
				//console.log("BLElog长度",BLEloglen);
				this.BLElog60 = this.BLElog.slice(BLEloglen - 10, BLEloglen);
				console.log('current(nA):', current, '总长度', BLEloglen);
			});
		},

		//日期格式化
		dateFormat(time) {
			let date = new Date(time);
			let year = date.getFullYear();
			// 在日期格式中，月份是从0开始的，因此要加0，使用三元表达式在小于10的前面加0，以达到格式统一  如 09:11:05
			let month = date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1;
			let day = date.getDate() < 10 ? '0' + date.getDate() : date.getDate();
			let hours = date.getHours() < 10 ? '0' + date.getHours() : date.getHours();
			let minutes = date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes();
			let seconds = date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds();
			// 拼接
			return year + '/' + month + '/' + day + '/' + hours + ':' + minutes + ':' + seconds;
			// return year + "-" + month + "-" + day;
		},

		clearLog() {
			let NullLog = [];

			let NullLogJS = JSON.stringify(NullLog);

			uni.setStorage({
				key: 'BLElog',
				data: NullLogJS,
				success: function () {
					console.log('成功清空日志文件BLElog');
					this.BLElog = [];
				},
				fail: function () {
					console.log('清空日志文件失败BLElog');
				}
			});

			uni.setStorage({
				key: 'glulog',
				data: NullLogJS,
				success: function () {
					console.log('成功清空日志文件glulog');
					this.glulog = [];
				},
				fail: function () {
					console.log('清空日志文件失败glulog');
				}
			});

			uni.setStorage({
				key: 'BLEoperationLog',
				data: NullLogJS,
				success: function () {
					console.log('成功清空日志文件BLEoperationLog');
					this.BLEoperationLog = [];
				},
				fail: function () {
					console.log('清空日志文件失败BLEoperationLog');
				}
			});

			uni.setStorage({
				key: 'BLECurrentLog',
				data: NullLogJS,
				success: function () {
					console.log('成功清空日志文件BLECurrentLog');
					this.BLECurrentLog = [];
				},
				fail: function () {
					console.log('清空日志文件失败BLECurrentLog');
				}
			});
		},

		clearAllTimer() {},

		recreateBLEConnection() {
			let reconnectTimer = setInterval(() => {
				let restatus = 0;
				let deviceId = this.deviceId;
				uni.createBLEConnection({
					// 这里的 deviceId 需要已经通过 createBLEConnection 与对应设备建立链接
					deviceId,
					success: (res) => {
						console.log('设备连接成功！');
						let notifyCid = this.notifyCid;
						this.notifycurrent(notifyCid);
						this.pushCommandInlog('Bluetooth reconnected');

						restatus = 1;
						this.clearIntervalTimer(reconnectTimer);
					},
					fail: (res) => {
						console.log(JSON.stringify(res));
						console.log('设备连接失败！');
						if (res.code == -1) {
							restatus = 1;
							this.clearIntervalTimer(reconnectTimer);
							this.notifycurrent(this.notifyCid);
							this.pushCommandInlog('Bluetooth reconnected');
						}
					}
				});

				//重新开始监听
			}, 1000);
			//先初始化

			//再次开启策略
		},

		onBLEConnectionStateChange() {
			uni.onBLEConnectionStateChange((res) => {
				// 该方法回调中可以用于处理连接意外断开等异常情况
				console.log(`device ${res.deviceId} state has changed, connected: ${res.connected} `);
				if (res.connected == false) {
					this.pushCommandInlog('Bluetooth disconnected');
					this.recreateBLEConnection();
				}
			});
		},

		/**
		 * 断开蓝牙连接
		 */
		closeBluetoothAdapter() {
			uni.closeBluetoothAdapter({
				success: (res) => {
					console.log('断开蓝牙模块成功');

					uni.showToast({
						icon: 'none',
						title: '蓝牙已经断开！',
						mask: false,
						duration: 3000
					});
				}
			});
		}
	}
};
</script>

<style lang="scss">
@mixin flex {
	/* #ifndef APP-NVUE */
	display: flex;
	/* #endif */
	flex-direction: row;
}

@mixin height {
	/* #ifndef APP-NVUE */
	height: 100%;
	/* #endif */
	/* #ifdef APP-NVUE */
	flex: 1;
	/* #endif */
}

.box {
	@include flex;
	font-size: 20px;
}

.button {
	@include flex;
	align-items: center;
	justify-content: center;
	flex: auto;
	height: auto;
	margin: 0 5px;
	border-radius: 5px;
}

.example-body {
	background-color: #fff;
	padding: 10px 0;
	font-size: 8px;
}

.uni-common-mt {
	margin-top: 30px;
}

.box {
	font-size: 13px;
}

.content {
	/* #ifndef APP-NVUE */
	display: flex;
	/* #endif */
	justify-content: center;
	align-items: flex-start;
	height: 470px;
	text-align: center;
}

.uni-list {
	flex: 1;
}

.uni-list-item {
	/* #ifndef APP-NVUE */
	display: flex;
	/* #endif */
	flex: 1;
	flex-direction: row;
	background-color: #ffffff;
}

.uni-list-item__container {
	padding: 12px 15px;
	width: 100%;
	flex: 1;
	position: relative;
	/* #ifndef APP-NVUE */
	display: flex;
	box-sizing: border-box;
	/* #endif */
	flex-direction: row;
	justify-content: space-between;
	align-items: center;
	border-bottom-style: solid;
	border-bottom-width: 1px;
	border-bottom-color: #eee;
}

.uni-list-item__content-title {
	font-size: 14px;
}

.dialog-text {
	font-size: 16px;
	color: #333;
}
.bigb {
	font-size: 25px;
}
.primary-button {
	padding: 10px 20px;
	width: 40%;
	background-color: #aa0000;
	color: #fff;
	border: none;
	border-radius: 10px;
	cursor: pointer;
}
</style>
