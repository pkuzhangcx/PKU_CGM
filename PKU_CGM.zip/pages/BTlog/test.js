function getJsonData(path) { 
	return new Promise(resolve => { 
		plus.io.requestFileSystem(plus.io.PUBLIC_DOCUMENTS, fs => {
				fs.root.getFile(
					path, {
						create: true 
					}, fileEntry => {
						fileEntry.file(function(file) {
							let fileReader = new plus.io
								.FileReader(); 
							fileReader.readAsText(file, "utf-8"); 
							fileReader.onerror = e => { 
								plus.nativeUI.toast("获取文件失败,请重启应用", {
									background: "rgba(255, 255, 255, 0.6)",
								});
								return;
							};
							fileReader.onload = e => { 
								console.log("读取文件成功");
								console.log(e);
								let txtData = e.target.result;
								resolve(txtData); 
							};
						});
					}, error => {
						console.log("2新建获取文件失败", error);
						plus.nativeUI.toast("获取文件失败,请重启应用", {
							background: "rgba(255, 255, 255, 0.6)",
						});
						return;
					});
			},
			e => {
				console.log("1请求文件系统失败", e.message);
				plus.nativeUI.toast("请求系统失败,请重启应用", {
					background:  "rgba(255, 255, 255, 0.6)",
				});
				return;
			}
		);
	});
};
// 写入josn文件
function changeData(path, seek, writeData) {
	return new Promise(resolve => {
		plus.io.requestFileSystem(plus.io.PUBLIC_DOCUMENTS, fs => {
			fs.root.getFile(path, {
					create: true
				}, fileEntry => {
					console.log(300000)
					console.log(fileEntry.fullPath)
					fileEntry.file(file => {
						fileEntry.createWriter(writer => {
							 console.log( fs.root.toURL(),'路径111')
								plus.nativeUI.showWaiting("正在保存信息");
								writer.seek(seek); 
								const writeDataTemp = JSON.stringify(writeData, null,
									"\r").replace(/[\r]/g, "");
								writer.write(writeDataTemp); 
								writer.onerror = function() {
									console.log("4写入文件失败", writer.error.message);
									plus.nativeUI.closeWaiting();
									plus.nativeUI.toast("修改信息失败,请重新操作", {
										background: "rgba(255, 255, 255, 0.6)",
									});
									return;
								};
								writer.onsuccess = function(e) { 
								
									plus.nativeUI.closeWaiting();
									resolve("1");
								};
							},
							error => {
								console.log("3创建creactWriter失败", error);
								plus.nativeUI.toast("保存文件失败,请重新操作", {
									// background: "#ffa38c",
								});
								return;
							});
					});
				},
				error => {
					console.log("2获取文件失败", error);
					plus.nativeUI.toast("保存文件失败,请重新操作", {
						// background: "#ffa38c",
					});
					return;
				}
			);
		}, e => {
			console.log("1请求文件系统失败", e.message);
			plus.nativeUI.toast("请求系统失败,请重新操作", {
				// background: "#ffa38c",
			});
			return;
		});
	});
}

//将这些方法暴露出去
export {
	getJsonData,
	changeData,
};

