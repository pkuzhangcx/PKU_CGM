<template>
	<view>
		<uni-list>
			<uni-list-item title="User List" thumb="/static/iconfont/user2.png" link to ="/pages/userlist/userlist" ></uni-list-item>
			<uni-list-item title="System settings" thumb="/static/iconfont/setting.png" link to ="/pages/CGMsetting/CGMsetting"></uni-list-item>
			<uni-list-item title="Strategy settings" thumb="/static/iconfont/circle.png" link to ="/pages/Circlesetting/Circlesetting"></uni-list-item>
		</uni-list>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			goUserlist(){
				
			},
			goCGMlist(){
				
			},
			goCirclelist(){
				
			},
		}
	}
</script>

<style>

</style>
