<template>
	<view>
		<button class="bigb"  @click="createBLEConnection(deviceId)">Device: {{ deviceId }},{{ btconnectStatusZ }}</button>
		<button class="bigb" @click="getBLEDeviceServices">Get BLE Device Services</button>

		<uni-list>
			<uni-list-item :title="'Service Id:' + serviceId">
				<text>av</text>
			</uni-list-item>
			<uni-list-item :title="'Write Id:' + writeCId"></uni-list-item>
			<uni-list-item :title="'Notify Id:' + notifyCid"></uni-list-item>
		</uni-list>
		<uni-section title="Strategy" type="line" padding>
			<uni-data-select v-model="value" :localdata="StrategyList" @change="changeStrategy" placeholder="Please select"></uni-data-select>
		</uni-section>
		<button class="bigb" @click="goCGMsettting">go System setttings</button>
		<button class="bigb" @click="goCirclesettting">go Strategy setttings</button>
		<button class="bigb" @click="goBTlog">go BTlog</button>
	</view>
</template>

<script>
export default {
	data() {
		return {
			btconnectStatusZ: 'disconnected',
			//主服务的UUID
			primaryUUID: 'FFF0',
			//设备列表
			devicesList: {},
			//特征值列表
			serviceList: [],
			characteristicList: [],
			//读写特征值
			writeCId: '',
			//监听特征值
			notifyCid: '',
			//设备Id
			deviceId: '',
			//服务Id
			serviceId: '',
			//策略模式
			StrategyMode: '',
			value: '',
			StrategyList: [
				{ value: 0, text: 'None' },
				{ value: 1, text: 'Open Loop' },
				{ value: 2, text: 'Closed Loop' }
			]
		};
	},
	onLoad() {
		const deviceId = uni.getStorageSync('deviceId');
		this.deviceId = deviceId;
		
		// const serviceId = uni.getStorageSync('serviceId');
		// this.serviceId = serviceId;
		
		// const writeCId = uni.getStorageSync('writeCId');
		// this.writeCId = writeCId;
		
		// const notifyCid = uni.getStorageSync('notifyCid');
		// this.notifyCid = notifyCid;
		
		
	},

	methods: {
		//选择泵策略
		changeStrategy(e) {
			console.log('e:', e);
			this.StrategyMode = e;
			uni.setStorageSync('StrategyMode', e);
		},

		//跳转蓝牙日志页面
		goBTlog() {
			uni.navigateTo({
				url: `../BTlog/BTlog`,
				success: (res) => {
					console.log('跳转成功');
				},
				fail: () => {
					console.log('跳转失败');
				},
				complete: () => {}
			});
		},

		goCGMsettting() {
			uni.navigateTo({
				url: `../CGMsetting/CGMsetting`,
				success: (res) => {
					console.log('跳转成功');
				},
				fail: () => {
					console.log('跳转失败');
				},
				complete: () => {}
			});
		},
		goCirclesettting() {
			uni.navigateTo({
				url: `../Circlesetting/Circlesetting`,
				success: (res) => {
					console.log('跳转成功');
				},
				fail: () => {
					console.log('跳转失败');
				},
				complete: () => {}
			});
		},

		//获取蓝牙读写监听特征值
		goadaptservices() {
			let deviceId = this.deviceId;
			let serviceId = this.serviceId;
			let characteristics = [];
			uni.getBLEDeviceCharacteristics({
				// 这里的 deviceId 需要已经通过 createBLEConnection 与对应设备建立链接
				deviceId,
				// 这里的 serviceId 需要在 getBLEDeviceServices 接口中获取
				serviceId,
				success: (res) => {
					console.log('device getBLEDeviceCharacteristics:', res.characteristics);
					this.characteristicList = res.characteristics;
					console.log(this.characteristicList);
					this.writeCId = res.characteristics[0].uuid;
					uni.setStorageSync('writeCId', res.characteristics[0].uuid);

					this.notifyCid = res.characteristics[1].uuid;
					uni.setStorageSync('notifyCid', res.characteristics[1].uuid);
				}
			});
		},
		//下一步按钮
		/**
		 * 连接设备
		 */

		createBLEConnection(deviceId) {
			//设备deviceId
			uni.openBluetoothAdapter({
				success: (e) => {
					console.log('初始化蓝牙成功:' + e.errMsg);
					this.$data.isOpenBle = true;
					console.log(this.$data.isOpenBle);
				},
				fail: (e) => {
					console.log('初始化蓝牙失败，错误码：' + (e.errCode || e.errMsg));
					//this.btStatus=false
				}
			});

			let self = this;
			uni.createBLEConnection({
				// 这里的 deviceId 需要已经通过 createBLEConnection 与对应设备建立链接
				deviceId,
				success: (res) => {
					console.log('设备连接成功！');
					this.btconnectStatusZ = 'Connected';
					//添加已连接蓝牙信息到历史记录中
					//this.pushthisBLEdata();

					//延迟1.5s获取设备的services
					setTimeout(function () {
						console.log('获取设备的services');
						self.getBLEDeviceServices();
					}, 4000);
				},
				fail: (res) => {
					console.log(JSON.stringify(res));
					console.log('设备连接失败！');
				}
			});
		},

		/**
		 * 获取设备的服务ID
		 */
		getBLEDeviceServices() {
			let deviceId = this.deviceId;
			let serviceList = [];
			let self = this;
			uni.getBLEDeviceServices({
				// 这里的 deviceId 需要已经通过 createBLEConnection 与对应设备建立链接
				deviceId,
				success: (res) => {
					console.log(JSON.stringify(res));
					this.serviceList = res.services;
					serviceList = res.services;
					console.log(this.serviceList);
					for (let i = 0; i < serviceList.length; i++) {
						let service = serviceList[i];
						console.log(JSON.stringify(service) + '----serviceID：' + service.uuid);
						//比对service是否是FFF0服务
						if (service.uuid.indexOf(self.primaryUUID) != -1) {
							self.serviceId = service.uuid;
							console.log('设备的serviceId： ' + self.serviceId);
							//开始获取指定服务的特征值
							uni.setStorageSync('serviceId', service.uuid);

							self.goadaptservices();
							break;
						}
					}
				},
				fail: (res) => {
					console.log('device services:', res.services);
				}
			});
		},
		onBLEConnectionStateChange() {
			let count = 0;
			uni.onBLEConnectionStateChange((res) => {
				// 该方法回调中可以用于处理连接意外断开等异常情况
				console.log(`蓝牙连接状态 -------------------------->`);
				console.log(JSON.stringify(res));
				if (!res.connected) {
					if (this.isStop) return;
					console.log('断开低功耗蓝牙成功:');

					uni.showToast({
						icon: 'none',
						title: '蓝牙已经断开！',
						mask: false,
						duration: 3000
					});

					//在这里尝试重连
					//this.createBLEConnection();
					//关闭连接
					this.closeBluetoothAdapter();
				}
			});
		},
		/**
		 * 断开蓝牙连接
		 */
		closeBluetoothAdapter() {
			uni.closeBluetoothAdapter({
				success: (res) => {
					console.log('断开蓝牙模块成功');

					uni.showToast({
						icon: 'none',
						title: '蓝牙已经断开！',
						mask: false,
						duration: 3000
					});
				}
			});
		}
	}
};
</script>

<style lang="scss">
.button-text {
	color: #fff;
	font-size: 12px;
}

.share .button {
	/* #ifndef APP-NVUE */
	width: 100%;
	/* #endif */
	margin: 0;
	margin-top: 10px;
	padding: 3px 0;
	flex: 1;
}
.share {
	/* #ifndef APP-NVUE */
	display: flex;
	/* #endif */
	flex-direction: column;
}
.bigb {
	font-size: 25px;
}
</style>