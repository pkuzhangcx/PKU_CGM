<template>
	<view>
		<uni-section titleFontSize="20px" subTitleFontSize="18px" title="Strategy Settings" sub-title="The normal range of human blood sugar is between 3.9 and 7.8" type="line">
			<text class="uni-subtitle">upperLimit：{{ '"' + OCsettingStorage.upperLimit + '"' }}, lowerLimit：{{ '"' + OCsettingStorage.lowerLimit + '"' }}</text>
			<uni-easyinput v-model="OCsetting.upperLimit"  @change="input" type="number"></uni-easyinput>
			<uni-easyinput v-model="OCsetting.lowerLimit" @change="input"  type="number"></uni-easyinput>
		</uni-section>
		<uni-section titleFontSize="20px" subTitleFontSize="18px" title="Radical mode" sub-title="In this mode, the pump output voltage is high, suitable for higher blood glucose levels" type="line">
			<text class="uni-subtitle">
				This mode will be entered between{{ '"' + OCsettingStorage.gluHighLevel + '"' }}-{{ '"' + OCsettingStorage.upperLimit + '"' }}and the pump voltage in this mode is{{
					'"' + OCsettingStorage.pumpHighLevelV + '"'
				}}mV
			</text>
			<uni-easyinput v-model="OCsetting.gluHighLevel"  @change="input" type="number"></uni-easyinput>
			<uni-easyinput v-model="OCsetting.pumpHighLevelV" @change="input"  type="number"></uni-easyinput>
		</uni-section>
		<uni-section titleFontSize="20px" subTitleFontSize="18px" title="Robust mode" sub-title="In this mode, the pump output voltage is normal, suitable for normal blood glucose levels" type="line">
			<text class="uni-subtitle">
				This mode will be entered between{{ '"' + OCsettingStorage.gluLowLevel + '"' }}-{{ '"' + OCsettingStorage.gluHighLevel + '"' }}and the pump voltage in this mode is{{
					'"' + OCsettingStorage.pumpMidLevelV + '"'
				}}mV
			</text>
			<uni-easyinput v-model="OCsetting.pumpMidLevelV" @change="input"  type="number"></uni-easyinput>
		</uni-section>
		<uni-section titleFontSize="20px" subTitleFontSize="18px" title="Cautious mode" sub-title="In this mode, the pump output voltage is low, suitable for lower blood glucose levels" type="line">
			<text class="uni-subtitle">
				This mode will be entered between{{ '"' + OCsettingStorage.lowerLimit + '"' }}-{{ '"' + OCsettingStorage.gluLowLevel + '"' }}and the pump voltage in this mode is{{
					'"' + OCsettingStorage.pumpLowLevelV + '"'
				}}mV
			</text>
			<uni-easyinput v-model="OCsetting.gluLowLevel"  @change="input" type="number"></uni-easyinput>
			<uni-easyinput v-model="OCsetting.pumpLowLevelV" @change="input"  type="number"></uni-easyinput>
		</uni-section>
		<button type="default" @click="saveconfig">Save Settings</button>
	</view>
</template>

<script>
export default {
	data() {
		return {
			OCsetting: {
				upperLimit: 10,
				lowerLimit: 3.9,
				gluHighLevel: 7.8,
				pumpHighLevelV: 500,
				pumpMidLevelV: 0,
				gluLowLevel: 5,
				pumpLowLevelV: 0
			},
			OCsettingStorage: {
				upperLimit: 10,
				lowerLimit: 3.9,
				gluHighLevel: 7.8,
				pumpHighLevelV: 500,
				pumpMidLevelV: 0,
				gluLowLevel: 5,
				pumpLowLevelV: 0
			}
		};
	},
	methods: {
		input(e) {
			console.log('输入内容：', e);
		},
		saveconfig() {
			let OCsetting = JSON.stringify(this.OCsetting);

			uni.setStorageSync('OCsetting', OCsetting);
			uni.showToast({
				title: '保存成功！',
				duration: 3000
			});
			let OCsettingStorage = uni.getStorageSync('OCsetting');
			this.OCsettingStorage = JSON.parse(OCsettingStorage);
		}
	}
};
</script>

<style>
.bigb {
	font-size: 22px;
}
</style>
