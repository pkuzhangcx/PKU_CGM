<template>
	<view>
		<uni-card title="基础卡片" sub-title="副标题" extra="额外信息" padding="10px 0">
			<template v-slot:title>
				<!-- <uni-list>
					<uni-list-item title="Blood glucose interval distribution" />
				</uni-list> -->
				<view class="box">
					<text class="bigb">Blood glucose interval distribution</text>
				</view>
			</template>
			<view class="ecdiv" id="ec_id2">
				<canvas canvas-id="myid2" id="myid2" class="charts" style="width: 100%; height: 100%" @tap.stop="tap" />
			</view>
			<!-- <image style="width: 100%" src="/static/iconfont/cake.jpg"></image> -->
			<text class="bigb">
				By observing the distribution pie chart of normal blood glucose intervals, you can understand the distribution of each interval, thereby better understanding your blood glucose status.
			</text>
		</uni-card>
	</view>
</template>

<script>
	import uCharts from './u-charts.min.js';
	// import uCharts from './u-charts.js';
	var uChartsInstance = {};
	
	export default {
		data() {
			return {
				key: [],
				glulog: [],
				
				//血糖范围
				lowGlu: 20.1,
				midGlu: 71.2,
				highGlu: 28,
				
				baseSettingStorage: {
					coefficient_a: 10,
					coefficient_b: 250,
					maximum2hours: 30,
					beforeMeal: 20
				},
				
				BLECurrentLog: [
					{
						time: '',
						current: ''
					}
				],
				
				cWidth2: 353,
				cHeight2: 400,
				max1: 12,
				
				opts: {
					color: ['#1890FF', '#91CB74', '#FAC858', '#EE6666', '#73C0DE', '#3CA272', '#FC8452', '#9A60B4', '#ea7ccc'],
					padding: [15, 30, 0, 0],
					dataLabel: false,
					dataPointShape: false,
					enableScroll: true,
					legend: {},
					xAxis: {
						fontSize: 10,
						disableGrid: true,
						labelCount: 4,
						scrollShow: true,
						itemCount: 200,
						ontouch: true
						// disabled:true,
					},
					yAxis: {
						gridType: 'dash',
						dashLength: 2,
						data: [
							{
								min: 0,
								max: 15,
							}
						]
					},
					extra: {
						line: {
							type: 'curve',
							width: 2,
							activeType: 'hollow',
							linearType: 'custom',
							onShadow: true,
							animation: 'horizontal'
						}
					}
				},
			}
		},
		onShow(options) {
			console.log(56666);
			//console.log(uCharts);
		
			setTimeout(() => {
				const BLECurrentLog = uni.getStorageSync('BLECurrentLog');
				if (BLECurrentLog) {
					this.BLECurrentLog = JSON.parse(BLECurrentLog);
					console.log('电流日志完成加载', this.BLECurrentLog);
				}
		
				const BLElog60 = uni.getStorageSync('BLElog60');
				if (BLElog60) {
					this.BLElog60 = JSON.parse(BLElog60);
					console.log('最近电流完成加载', this.BLElog60);
				}
		
				const glulog = uni.getStorageSync('glulog');
				if (glulog) {
					this.glulog = JSON.parse(glulog);
					console.log('最近电流完成加载', this.glulog);
				}
		
				this.getglu();
			}, 30);
		
			setTimeout(() => {
				this.getServerData2();
			}, 50);
		},
		methods: {
			getServerData2() {
				//代码演示
				const query = uni.createSelectorQuery().in(this);
				query
					.select('#ec_id2')
					.boundingClientRect((data) => {
						console.log('得到布局位置信息' + JSON.stringify(data));
						console.log('节点离页面顶部的距离为' + data.top);
						this.cWidth2 = data.width;
						this.cHeight2 = data.height;
					})
					.exec();
			
				//模拟数据  等有数据后改为时间数据
				let res = {
					series: [
						{
							data: [
								{
									name: 'Hypoglycemia', //名称---------
									value: this.lowGlu //值 会自动计算成百分百
								},
								{
									name: 'Normal',
									value: this.midGlu
								},
								{
									name: 'Hyperglycemia',
									value: this.highGlu
								}
							]
						}
					]
				};
				this.drawCharts2('myid2', res);
			},
			drawCharts2(id, data) {
				const ctx = uni.createCanvasContext(id, this);
				uChartsInstance[id] = new uCharts({
					type: 'pie',
					context: ctx,
					width: this.cWidth2,
					height: this.cHeight2,
					series: data.series,
					animation: true,
					background: '#FFFFFF',
					color: ['#1890FF', '#91CB74', '#FAC858', '#EE6666', '#73C0DE', '#3CA272', '#FC8452', '#9A60B4', '#ea7ccc'],
					padding: [5, 5, 5, 5],
					enableScroll: false,
					fontSize: 20,
					legend:{
						// position: "right",
						lineHeight: 50
					},
					extra: {
						pie: {
							activeOpacity: 0.5,
							activeRadius: 10,
							offsetAngle: 0,
							labelWidth: 15,
							border: true,
							borderWidth: 3,
							borderColor: '#FFFFFF',
							linearType: 'custom'
						}
					}
				});
			},
		}
	}
</script>

<style scoped>
.ecdiv {
	display: flex;
	width: 100%;
	height: 900rpx;
	/* background-color: #b1b1b1; */
}

.charts {
	width: 550rpx;
	height: 500rpx;
	/* background-color: aqua; */
}

.bigb {
	font-size: 20px;
}
.box{
	padding: 10px 0;
}
</style>