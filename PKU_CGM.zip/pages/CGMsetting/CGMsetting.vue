<template>
	<view>
		<uni-section titleFontSize="20px" subTitleFontSize="18px" title="Set Calibration Curve" sub-title="current = a*glu + b" type="line">
			<uni-easyinput v-model="baseSetting.coefficient_a"  @change="input" type="number"></uni-easyinput>
			<uni-easyinput v-model="baseSetting.coefficient_b"  @change="input" type="number"></uni-easyinput>
		</uni-section>
		<uni-section titleFontSize="20px" subTitleFontSize="18px" title="Set the amount of insulin injection before meals" sub-title="Default value: 10(min*V)" type="line">
			<uni-easyinput v-model="baseSetting.beforeMeal"  @change="input" type="number"></uni-easyinput>
		</uni-section>
		<uni-section titleFontSize="20px" subTitleFontSize="18px" title="Set the maximum 2-hour insulin pump dose" sub-title="Default value: 21(min*V)" type="line">
			<uni-easyinput v-model="baseSetting.maximum2hours"  @change="input" type="number"></uni-easyinput>
		</uni-section>
		<uni-section titleFontSize="20px" subTitleFontSize="18px" title="Set the maximum 2-hour insulin pump dose at night" sub-title="Default value: 15(min*V)" type="line">
			<uni-easyinput v-model="baseSetting.maximum2hours_night"  @change="input" type="number"></uni-easyinput>
		</uni-section>
		<uni-section titleFontSize="20px" subTitleFontSize="18px" title="Set the daytime begin and end" sub-title="Default value: 4-22" type="line">
			<uni-easyinput v-model="baseSetting.daytime_begin"  @change="input" type="number"></uni-easyinput>
			<uni-easyinput v-model="baseSetting.daytime_end"  @change="input" type="number"></uni-easyinput>
		</uni-section>

		<button type="default" class="bigb" @click="saveconfig">Save Settings</button>
	</view>
</template>

<script>
export default {
	data() {
		return {
			baseSetting: {
				coefficient_a: 10,
				coefficient_b: 400,
				maximum2hours: 21,
				maximum2hours_night:15,
				daytime_begin: 4,
				daytime_end: 22,
				beforeMeal: 10
			},
			baseSettingStorage: {
				coefficient_a: 10,
				coefficient_b: 400,
				maximum2hours: 21,
				maximum2hours_night:15,
				daytime_begin: 4,
				daytime_end: 22,
				beforeMeal: 10
			},
			

			placeholderStyle: 'color:#aa0000;font-size:14px'
		};
	},
	methods: {
		input(e) {
			console.log('输入内容：', e);
		},
		saveconfig() {
			let baseSetting = JSON.stringify(this.baseSetting);
			uni.setStorageSync('baseSetting', baseSetting);
			uni.showToast({
				title: '保存成功！',
				duration: 3000
			});
			let baseSettingStorage = uni.getStorageSync('baseSetting');
			this.baseSettingStorage = JSON.parse(baseSettingStorage);
		}
	}
};
</script>

<style>
	
.bigb {
	font-size: 22px;
}
</style>
