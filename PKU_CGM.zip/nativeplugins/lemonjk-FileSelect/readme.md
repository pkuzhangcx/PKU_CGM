<a name="lemonjk-FileSelect"></a>
# lemonjk-FileSelect
!!!有疑问请不要点击咨询作者（因为我收不到），请直接在插件下方评论回复（或加q群讨论：466852060）<br />**使用前须知：**<br />**1.本插件已更新到4.0.0，此版本插件已完全进行重构，与之前版本的使用方式不完全兼容，但大多数配置仍可使用，详见新版本说明。**<br />**2.请将此版本插件（4.0.0）作为单独的文件选择插件使用。**<br />**3.为避免与之前版本插件可能存在的冲突，使用此版本（4.0.0）前请移除插件的其它版本。**<br />**4.新版本（4.0.0）变更如下：**

- **新增：（安卓）全新UI界面的自定义文件选择器，适配夜间模式，根据系统自动切换。**
- **新增：（安卓）新增API,可以获取当前手机连接的所有外接存储设备(sd卡、u盘、移动硬盘等)，并可指定访问对应的外接存储设备**
- **删除：（安卓）移除之前版本中的/data目录访问相关API，如有需要请使用之前的版本。（重构中，后续重新支持）**
- **修复：（安卓）修复了之前版本在进行大文件（>1G）选取时出现白屏、卡死。**
- **优化：（安卓）多线程处理大文件读取，选取更快，异步返回结果。**
- **优化：（安卓）在文件读取时会有加载提示，更好的用户体验。**
- **变更：（安卓）之前版本只能使用系统内置文件选择器，新版本有原生和自定义文件选择器可供选择。（由于部分用户反映需要自定义界面，现可自行进行定制）**
   - **原生文件选择器**和**自定义文件选择器**有何区别？    
      - 原生文件选择器是安卓系统内置的。不可定制界面，与应用风格不协调，可配置属性少，无法满足定制化需求，操作体验不好。但是可以不用申请各种权限，官方推荐，可以让用户放心隐私问题。
      - 自定义文件选择器是开发者自行制作编写的。界面可任意定制，理论上可配置任何属性样式，满足定制化需求，但需要申请读写权限，高版本安卓**（**13.x**）**还需要MANAGE_EXTERNAL_STORAGE权限，此权限可能上架不了谷歌商店。
   - 我该如何选择？
      - 第一要考虑的就是是否需要上架**谷歌商店**，若无此方面考虑则可放心使用**自定义文件选择器。**
      - 看老板怎么说？原生文件选择器界面太丑？改！
      - 当原生文件选择器没办法满足特定的需求，如：指定只能选择特定的几个文件类型（其实可以在用户选择后对后缀名作判断，让用户重新选择），建议使用**自定义文件选择器**
      - 只是简单选择个文件？建议使用**原生文件选择器**
- **更多可配置项开发中（多选）**
<a name="72e48a99"></a>
# 一、基本使用
> <a name="yoRI4"></a>
#### 使用前须知：
> - 推荐优先使用【下载for离线打包】方式下载插件包，然后在项目中引入。此方式同样可以云打包，而插件包是存放在本地项目中的，所以不用开发者绑定账号，任何人复制你的项目都可以使用插件运行，更适合多人开发项目，交付项目。可以不受插件后续版本更新的影响。[https://ask.dcloud.net.cn/article/35844](https://ask.dcloud.net.cn/article/35844)
> - ~~重要（安卓）：请在manifest配置满足以下要求: minSDKVersion>=21      targetSdkVersion<=32。~~
>       1. ~~原因一:为什么不支持 targetSdkVersion 33？因为权限发生较大变化，部分目录已无法获取，需要MANAGE_EXTERNAL_STORAGE权限读取文件，谷歌市场上架只允许文件管理类app可以申请这个权限。~~
>       2. ~~原因二:以Android13（API 33+）为目标平台的应用，系统新增运行时权限READ_MEDIA_IAMGES、READ_MEDIA_VIDEO、READ_MEDIA_AUDIO 替代原有的READ_EXTERNAL_STORAGE权限（未适配,后续适配）。~~
> - 已适配安卓13.x( SdkVersion>=33) ,为满足上架谷歌商店的新应用需要targetSdkVersion>=33，新版插件(>=3.1版)经测试可以在targetSdkVersion>=33条件下正常选取文件
> - 已在部分真机(详情见：二、兼容性说明)测试通过,其他系统版本、机型未知，请自行测试。
> - 特性（安卓）：支持访问 'Android/data' 目录（需用户授权）,满足部分用户需要访问应用私有目录的需要。
> - 特性（安卓）：本插件已做自动权限检查，支持跳转到APP权限设置页。
> - 特性：支持限制文件类型选取（安卓为mime类型,ios为utis类型），实现限制文件类型选取。
> - 特性（安卓）：支持访问指定目录，方便用户在指定目录快速选取。
> - 特性：支持多选，同时选取多个文件。

<a name="myAHo"></a>
### 1.在页面引入
```javascript
const lemonjkFileSelect = uni.requireNativePlugin('lemonjk-FileSelect');
//提示：
//1.不要忘了在 "manifest.json -> APP原生插件配置" 内添加本插件，否则云打包（离线打包）不会生效
```
<a name="bf889e23"></a>
### 2.唤起文件选择
```javascript
lemonjkFileSelect.showPicker({
  //各属性配置见下方【showPicker可配置参数说明】
	pathScope: "/Download",  
	mimeType: "*/*",
	utisType:"public.data",
	multi:'yes',
	// securityPackageName: "com.android.egg",
	// securityScope: 'data'
	}, result => {
	// 返回值说明见下方【showPicker返回值说明】
			
	// （仅安卓）当错误码为1001，即未授权文件读取权限,可以提示用户未打开读取文件权限，并跳转设置页
	if(result.code==1001){
		uni.showModal({
			title:"需要文件访问权限",
			content:"您还未授权本应用读取文件。为保证您可以正常上传文件，请在权限设置页面打开文件访问权限（不同手机厂商表述可能略有差异）请根据自己手机品牌设置",
			confirmText:"去授权",
			cancelText:"算了",
			success(e) {
				if(e.confirm){
					// 跳转到应用设置页
					lemonjkFileSelect.gotoSetting();		
				}
			}
		})
	}
})
```
<a name="miDvi"></a>
# 二、插件方法和参数配置
<a name="EGUgt"></a>
### 1.showPicker
> **4.0.0安卓端变更为打开的是自定义文件选择器，如需打开原生文件选择器请调用：**
> **lemonjkFileSelect.showNativePicker**

唤起文件选择
```javascript
lemonjkFileSelect.showPicker({
	pathScope: "/Download",  
	mimeType: "*/*",
	utisType:"public.data",
	multi:'yes'
}, result => {})


//4.0.0+ 使用示例及高级筛选器配置示例
lemonjkFileSelect.showPicker({
					// multi: "yes", //多选，待开发，后续支持
					pathScope: "/Download",
					navTitle:"文件选择",
					navTextColor:'#55ff00',
					navBarBgColor:'#00aaff',  
					theme:'light',  //auto 跟随系统  light 亮色  dark 暗色 
					showHideFile:"yes",   //是否显示隐藏的文件和文件夹      
					filterConfig:{  //对象里配置的属性要同时满足   
						// fileName:['base.apk','config.txt','配置文件.yaml'],  //属性数组满足其中一项
						fileSize:String(1*1024*1024),  //byte 单位：字节
						fileExtension:['apk','txt','jpg','mp3','yaml'],  //属性数组满足其中一项 
					}
				}, result => {
					console.log(result);
				})
```
<a name="o9qkZ"></a>
#### 可配置参数说明
| **属性** | **类型** | **说明** | **兼容性（4.0.0指插件版本）** |
| --- | --- | --- | --- |
| navTitle | string | 顶部导航栏标题 | 仅【4.0.0】安卓自定义文件选择器 |
| navTextColor | string | 顶部导航栏文字颜色<br />如：  navTextColor:'#ffffff' | 仅【4.0.1】安卓自定义文件选择器，此优先级高于theme主题对应的颜色 |
| navBarBgColor | string | 顶部导航栏背景颜色<br />如：navBarBgColor:'#ffffff' | 仅【4.0.1】安卓自定义文件选择器，此优先级高于theme主题对应的颜色 |
| theme | string | 选择器外观主题，默认值为：auto<br />可选值**：auto** 跟随系统  **light** 亮色  **dark** 暗色 | 仅【4.0.1】安卓自定义文件选择器 |
| showHideFile | string | 是否显示隐藏的文件和文件夹<br />可选值：yes | 仅【4.0.0】安卓自定义文件选择器 |
| pathScope | string | 【可选】访问指定目录，不需要则不要声明该属性，默认显示顶级目录<br />例：<br />`/DCIM/Camera 相机 `<br /> `/Download 下载   `  | 仅安卓，部分目录由于安全策略无法访问,如`"Android/data"`，请自行测试，可以参考自己手机的目录进行设置<br />原生选择器指定目录需在Android 8.0及以上系统支持（如需**低版本**支持请使用插件4.0.0版的自定义文件选择器） |
| externalStoragePath | string | 如果pathScope路径为外接存储设备路径（从**getAllExternalStorage**中获取），需设置externalStoragePath为yes | 仅【4.0.0】安卓自定义文件选择器 |
| filterConfig | object | 高级筛选器配置，用于可选文件过滤，更高级的文件筛选功能，满足更复杂的文件筛选要求。<br />**filterConfig.fileName**  文件名筛选(Array<String>)<br />**filterConfig.fileSize**  文件大小筛选(String,单位：字节)<br />**filterConfig.fileExtension**  文件类型筛选(Array<String>)<br />具体使用见上方使用示例<br /> | 仅【4.0.1】安卓自定义文件选择器 |
| mimeType | string | 【必填】限制选取的文件类型，不限制需设为 `"*/*"`,更多类型请参照Mime类型对照表,暂时仅支持设置单个类型<br />例: <br />` image/*    （图片） `<br />` text/plain  （文本）`<br />`application/vnd.openxmlformats-officedocument.wordprocessingml.document （word）` | 仅安卓，ios使用utisType属性代替 |
| utisType | string | 【必填】限制选取的文件类型，不限制需设为`"public.data"`，更多类型请参照utis类型对照表,暂时仅支持设置单个类型<br />[utis对照表请点此前往](https://developer.apple.com/library/archive/documentation/Miscellaneous/Reference/UTIRef/Articles/System-DeclaredUniformTypeIdentifiers.html) | 仅ios，安卓使用mimeType代替 |
| multi | string | 【可选】是否开启多选，"yes"为开启,默认不填即为单选 | <br /> |
| securityPackageName | string | 【可选】`"Android/data"`下要访问的包名，可以参考自己手机目录"Android/data"下的包名进行设置<br />如果需要选取 `"Android/data"` 安全目录下的文件,请设置该属性，不需要则不要声明该属性 | 仅【<4.0.0】安卓<br /> |
| securityScope | string | 【可选】安全访问的根目录，暂时只支持 "data"<br />如果需要选取 `"Android/data"` 安全目录下的文件,请设置该属性，不需要则不要声明该属性<br />注：securityPackageName和securityScope需要同时设置才能访问 `"Android/data"`下的目录 | 仅【<4.0.0】安卓 |

<a name="f4ZTu"></a>
#### 返回值说明
| **属性** | **类型** | **说明** | **兼容性** |
| --- | --- | --- | --- |
| code | string<br />【4.0.0】安卓返回的状态码由之前的字符串类型改为数字类型int | 状态码:<br />0 成功<br />-1  未知错误<br />1001 未授权文件读取权限(文件访问权限错误)<br />1002 文件不存在（仅安卓）<br />1004 用户取消了选择(仅ios)<br />1005 文件选取出错(仅ios) | **危险变更,更新4.0.0安卓端**，**部分状态码的值发生了变更，请根据实际调试返回的状态码进行判断** |
| filePath | string | 选取的文件的绝对路径,可以直接提供给uniapp的上传、下载等api使用，需要二进制上传请使用plus5+API进行转换 | 请参考files |
| fileName | string | 选取的文件的名称 | 请参考files，**危险变更,为避免歧义，在【4.0.0】安卓端，fileRealName为实际在文件夹中的显示的名称，而fileName则为逻辑上的展示名称** |
| fileRealName | string | 选取的文件的真实名称 | 请参考files,<br />**危险变更,为避免歧义，在【4.0.0】安卓端，fileRealName为实际在文件夹中的显示的名称，而fileName则为逻辑上的展示名称** |
| fileSize | string | 选取的文件的大小（单位：字节） | 请参考files |
| fileExtension | string | 选取的文件的后缀名 | 请参考files |
| fileMime | string | 选取的文件的Mime类型 | 请参考files，仅【4.0.0】安卓原生文件选择器，本属性不保证返回，请勿以此作为唯一判断业务逻辑的属性 |
| files | array<br /> | 无论设置了单选还是多选，都以数组形式返回所选文件列表。如果单选，则数组长度为1，使用files[0]即可。<br />3.0版本**ios**新增的文件列表属性.单选和多选统一以数组形式返回,废弃了 result.fileName、result.fileSize、result.fileExtension、result.filePath、result.fileRealName<br />3.1版本**安卓**新增的文件列表属性.单选和多选统一以数组形式返回,废弃了 result.fileName、result.fileSize、result.fileExtension、result.filePath、result.fileRealName、result.fileMime<br />4.0.0版本**安卓**完全使用了files数组作为文件选择结果返回，无论设置单选还是多选。<br /> files结构如下：<br />`[{filePath,fileName,fileExtension,fileSize},...] ` | **危险变更,更新3.0，请注意适配(仅ios)**<br />**危险变更,更新3.1，请注意适配(仅安卓)**<br />**危险变更,更新4.0.0，请注意适配(仅安卓)** |
| errMsg | string | 选择完成后的状态信息  |  |
| detail | string | 具体的文字说明 |  |

<a name="be8802d0"></a>
### 2.gotoSetting(仅安卓)
跳转到应用设置页面
```javascript
lemonjkFileSelect.gotoSetting();
```
<a name="Wdr7Q"></a>
#### **可配置参数说明**
无
<a name="t08IO"></a>
#### 返回值说明
无
<a name="a74b98b3"></a>
### 3.grantSecurityScope（仅安卓<4.0.0）
打开安全目录授权页面
```javascript
//1.选取 "Android/data" 目录文件之前，需要调用此方法。
//2.用户同意授权后，才可使用lemonjkFileSelect.showPicker选取 "Android/data"目录下的文件,否则直接调用将不会。
//3.仅需用户首次授权即可，永久有效，除非应用被卸载。
lemonjkFileSelect.grantSecurityScope({
					securityScope:"data",
					securityPackageName: "com.android.egg" 
				}, result => {
					console.log(result);
					//  result.code       状态码【1005 用户授权成功】 
					//  result.errMsg     选择完成后的状态信息
					//  result.detail     具体的文字说明
         
				})
//提示:
//用户授权成功后，请自行保存维护该包名对应文件夹的授权记录
//如storage持久化：[{PackageName:"com.android.egg",isGrant:true}],
//以后无需调用lemonjkFileSelect.grantSecurityScope授权该包名下的文件夹，可直接调用lemonjkFileSelect.showPicker进行选取
```
<a name="qogHN"></a>
#### 可配置参数说明
| **属性** | **类型** | **说明** | **兼容性** |
| --- | --- | --- | --- |
| securityPackageName | string | 【可选】`"Android/data"`下要访问的包名，可以参考自己手机目录`"Android/data"`下的包名进行设置<br />如果需要选取 `"Android/data"` 安全目录下的文件,请设置该属性，不需要则不要声明该属性 | 仅安卓 |
| securityScope | string | 【可选】安全访问的根目录，暂时只支持 `"data"`<br />如果需要选取 `"Android/data" `安全目录下的文件,请设置该属性，不需要则不要声明该属性<br />注：securityPackageName和securityScope需要同时设置才能访问 `"Android/data"`下的目录 | 仅安卓 |

<a name="UTfoi"></a>
#### 返回值说明
| **属性** | **类型** | **说明** | **兼容性** |
| --- | --- | --- | --- |
| code | string | 状态码:<br />1005 用户授权成功（仅安卓） | <br /> |
| errMsg | string | 选择完成后的状态信息  |  |
| detail | string | 具体的文字说明 |  |

<a name="k2UgA"></a>
### 4.showNativePicker(仅4.0.0插件安卓)
跳转到应用设置页面<br />参考说明**1.showPicker**
<a name="k8jJd"></a>
### 5.getAllExternalStorage(仅4.0.0插件安卓)
获取外接存储设备列表，如sd卡、u盘、移动硬盘等
<a name="E0Iuh"></a>
#### **可配置参数说明**
无
<a name="INBU4"></a>
#### 返回值说明
返回当前手机所有已连接的**外接存储设备路径列表**，可使用该列表中的路径传给showPicker使用，实现打开对应外接设备文件选取
```javascript
lemonjkFileSelect.showPicker({
					pathScope: '这里填你要访问的外接设备路径',
					externalStoragePath:'yes',//如果路径为外接存储设备路径（从getAllExternalStorage中获取），需设置externalStoragePath为yes
					navTitle:"文件选择",
					showHideFile:"yes"   //是否显示隐藏的文件和文件夹
				}, result => {
					console.log(result);
				})
```
<a name="b9918820"></a>
# 二、兼容性说明
目前仅测试了部分系统版本,其他系统版本兼容性未知，请自行测试，测试可用可以反馈，帮助更多人。

<a name="4940564b"></a>
# 三、问题反馈与收集
感谢使用，如需使用[UTS]版文件选取，请使用此插件：[https://ext.dcloud.net.cn/plugin?id=12988](https://ext.dcloud.net.cn/plugin?id=12988)
```javascript
目前收集的问题（Q&A）：
1.(ios)控制台报错:自定义基座不包含本插件:请不要使用ios模拟器运行,使用真机运行即可
2.(安卓)选择大文件时短暂黑屏：4.0.0已解决
```

